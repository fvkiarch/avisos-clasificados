-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: avisos_clasificados
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auditoria_backup`
--

DROP TABLE IF EXISTS `auditoria_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditoria_backup` (
  `id_backup` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tipo` enum('COMPLETO','INCREMENTAL','PRUEBA_RESTAURACION') NOT NULL,
  `estado` enum('EN_CURSO','OK','ERROR') NOT NULL DEFAULT 'EN_CURSO',
  `fecha_inicio` datetime NOT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  `archivo` varchar(255) DEFAULT NULL,
  `tamano_bytes` bigint(20) unsigned DEFAULT NULL,
  `checksum_sha256` char(64) DEFAULT NULL,
  `usuario_bd` varchar(100) NOT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_backup`),
  KEY `idx_backup_fecha` (`fecha_inicio`),
  CONSTRAINT `ck_backup_fechas` CHECK (`fecha_fin` is null or `fecha_fin` >= `fecha_inicio`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria_backup`
--

LOCK TABLES `auditoria_backup` WRITE;
/*!40000 ALTER TABLE `auditoria_backup` DISABLE KEYS */;
INSERT INTO `auditoria_backup` VALUES (1,'COMPLETO','OK','2026-10-24 10:57:19','2026-10-24 10:57:19','avisos_2026-10-18_0200.sql.gz',48213,'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','root@localhost','Ejemplo'),(2,'COMPLETO','ERROR','2026-10-25 17:03:39','2026-10-25 17:03:39',NULL,NULL,NULL,'root@localhost','Fallo en línea 48'),(3,'COMPLETO','ERROR','2026-10-25 17:03:45','2026-10-25 17:03:45',NULL,NULL,NULL,'root@localhost','Fallo en línea 48'),(4,'COMPLETO','ERROR','2026-10-25 17:03:57','2026-10-25 17:03:57',NULL,NULL,NULL,'root@localhost','Fallo en línea 48'),(5,'COMPLETO','OK','2026-10-25 17:04:36','2026-10-25 17:04:36','avisos_clasificados_2026-10-25_1704.sql.gz',5628,'a9542535e40e14a4b3338260552fa4229ca2344dd47699e17fea43677c33f1b7','root@localhost','Retención 30 días'),(6,'COMPLETO','EN_CURSO','2026-10-25 17:05:10',NULL,NULL,NULL,NULL,'root@localhost',NULL);
/*!40000 ALTER TABLE `auditoria_backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `autor`
--

DROP TABLE IF EXISTS `autor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autor` (
  `id_autor` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `id_rol` tinyint(3) unsigned NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_autor`),
  UNIQUE KEY `uq_autor_email` (`email`),
  KEY `fk_autor_rol` (`id_rol`),
  CONSTRAINT `fk_autor_rol` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`) ON UPDATE CASCADE,
  CONSTRAINT `ck_autor_email` CHECK (`email` like '_%@_%._%'),
  CONSTRAINT `ck_autor_nombre` CHECK (char_length(trim(`nombre`)) > 0)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autor`
--

LOCK TABLES `autor` WRITE;
/*!40000 ALTER TABLE `autor` DISABLE KEYS */;
INSERT INTO `autor` VALUES (1,'Administrador','admin@avisos.test','099111111','$2y$10$ea0zZDG9qqkq43wUIoEFQ.cjMwLj4Az/PnWaRbKdqIovd/GEUmO0S',1,1),(2,'Lucía Pereira','lucia@avisos.test','099222222','$2y$10$ea0zZDG9qqkq43wUIoEFQ.cjMwLj4Az/PnWaRbKdqIovd/GEUmO0S',2,1),(3,'Martín Rodríguez','martin@avisos.test','099333333','$2y$10$ea0zZDG9qqkq43wUIoEFQ.cjMwLj4Az/PnWaRbKdqIovd/GEUmO0S',2,1),(4,'Carla Núñez','carla@avisos.test','099444444','$2y$10$ea0zZDG9qqkq43wUIoEFQ.cjMwLj4Az/PnWaRbKdqIovd/GEUmO0S',3,1),(5,'Bot Respaldo','respaldo@avisos.test',NULL,'$2y$10$ea0zZDG9qqkq43wUIoEFQ.cjMwLj4Az/PnWaRbKdqIovd/GEUmO0S',4,1);
/*!40000 ALTER TABLE `autor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aviso`
--

DROP TABLE IF EXISTS `aviso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aviso` (
  `id_aviso` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(150) NOT NULL,
  `fecha_creacion` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `resaltado` tinyint(1) NOT NULL DEFAULT 0,
  `id_autor` int(10) unsigned NOT NULL,
  `id_categoria` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id_aviso`),
  KEY `fk_aviso_autor` (`id_autor`),
  KEY `idx_aviso_orden` (`resaltado`,`fecha_creacion`,`id_aviso`),
  KEY `idx_aviso_cat_fecha` (`id_categoria`,`fecha_creacion`),
  CONSTRAINT `fk_aviso_autor` FOREIGN KEY (`id_autor`) REFERENCES `autor` (`id_autor`) ON UPDATE CASCADE,
  CONSTRAINT `fk_aviso_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`) ON UPDATE CASCADE,
  CONSTRAINT `ck_aviso_titulo` CHECK (char_length(trim(`titulo`)) > 0),
  CONSTRAINT `ck_aviso_resaltado` CHECK (`resaltado` in (0,1))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aviso`
--

LOCK TABLES `aviso` WRITE;
/*!40000 ALTER TABLE `aviso` DISABLE KEYS */;
INSERT INTO `aviso` VALUES (1,'Se busca desarrollador Rust','2026-10-24 13:57:19.037660',0,2,1),(2,'Técnico en redes','2026-10-24 13:57:19.040100',0,3,1),(3,'Notebook 14\" usada','2026-10-24 13:57:19.046482',0,2,2),(5,'Apartamento 2 dormitorios','2026-10-24 13:57:19.055271',0,2,3),(6,'Terreno en Ciudad de la Costa','2026-10-24 13:57:19.057606',0,3,3),(7,'Oferta: Monitor 34\" 2k IPS','2026-10-24 13:57:19.064180',1,1,2),(10,'Casa en Shangrilá','2026-10-24 19:16:42.334768',1,1,3);
/*!40000 ALTER TABLE `aviso` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_aviso_categoria_inmutable BEFORE UPDATE ON aviso FOR EACH ROW
BEGIN
  IF NEW.id_categoria <> OLD.id_categoria THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No se puede cambiar la categoría de un aviso';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aviso_inmobiliario`
--

DROP TABLE IF EXISTS `aviso_inmobiliario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aviso_inmobiliario` (
  `id_aviso` int(10) unsigned NOT NULL,
  `id_tipo_inmueble` tinyint(3) unsigned NOT NULL,
  `ubicacion` varchar(150) NOT NULL,
  `superficie_m2` decimal(10,2) NOT NULL,
  `precio` decimal(14,2) NOT NULL,
  PRIMARY KEY (`id_aviso`),
  KEY `fk_inmo_tipo` (`id_tipo_inmueble`),
  CONSTRAINT `fk_inmo_aviso` FOREIGN KEY (`id_aviso`) REFERENCES `aviso` (`id_aviso`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_inmo_tipo` FOREIGN KEY (`id_tipo_inmueble`) REFERENCES `tipo_inmueble` (`id_tipo_inmueble`) ON UPDATE CASCADE,
  CONSTRAINT `ck_inmo_superficie` CHECK (`superficie_m2` > 0),
  CONSTRAINT `ck_inmo_precio` CHECK (`precio` >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aviso_inmobiliario`
--

LOCK TABLES `aviso_inmobiliario` WRITE;
/*!40000 ALTER TABLE `aviso_inmobiliario` DISABLE KEYS */;
INSERT INTO `aviso_inmobiliario` VALUES (5,2,'Punta Gorda, Montevideo',58.50,165000.00),(6,3,'Lagomar, Canelones',420.00,72000.00),(10,1,'Shangrilá, Canelones',1300.00,120000.00);
/*!40000 ALTER TABLE `aviso_inmobiliario` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_inmo_categoria BEFORE INSERT ON aviso_inmobiliario FOR EACH ROW
BEGIN
  IF (SELECT c.nombre FROM aviso a JOIN categoria c ON c.id_categoria = a.id_categoria
      WHERE a.id_aviso = NEW.id_aviso) <> 'Inmobiliario' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El aviso no pertenece a la categoría Inmobiliario';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aviso_laboral`
--

DROP TABLE IF EXISTS `aviso_laboral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aviso_laboral` (
  `id_aviso` int(10) unsigned NOT NULL,
  `empresa` varchar(100) NOT NULL,
  `descripcion_cargo` text NOT NULL,
  `sueldo_mensual` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_aviso`),
  CONSTRAINT `fk_laboral_aviso` FOREIGN KEY (`id_aviso`) REFERENCES `aviso` (`id_aviso`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ck_laboral_sueldo` CHECK (`sueldo_mensual` is null or `sueldo_mensual` > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aviso_laboral`
--

LOCK TABLES `aviso_laboral` WRITE;
/*!40000 ALTER TABLE `aviso_laboral` DISABLE KEYS */;
INSERT INTO `aviso_laboral` VALUES (1,'Canonical','Desarrollo y colaboración de kernel.',85000.00),(2,'RedHat','Soporte de infraestructura, cableado y switching.',NULL);
/*!40000 ALTER TABLE `aviso_laboral` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_laboral_categoria BEFORE INSERT ON aviso_laboral FOR EACH ROW
BEGIN
  IF (SELECT c.nombre FROM aviso a JOIN categoria c ON c.id_categoria = a.id_categoria
      WHERE a.id_aviso = NEW.id_aviso) <> 'Laboral' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El aviso no pertenece a la categoría Laboral';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `aviso_producto`
--

DROP TABLE IF EXISTS `aviso_producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aviso_producto` (
  `id_aviso` int(10) unsigned NOT NULL,
  `descripcion_producto` text NOT NULL,
  `precio` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id_aviso`),
  CONSTRAINT `fk_producto_aviso` FOREIGN KEY (`id_aviso`) REFERENCES `aviso` (`id_aviso`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ck_producto_precio` CHECK (`precio` >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aviso_producto`
--

LOCK TABLES `aviso_producto` WRITE;
/*!40000 ALTER TABLE `aviso_producto` DISABLE KEYS */;
INSERT INTO `aviso_producto` VALUES (3,'Notebook i9, 128GB RAM, 10TB SSD. Excelente estado.',18500.00),(7,'Monitor IPS 175Hz, caja sellada.',7200.00);
/*!40000 ALTER TABLE `aviso_producto` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_producto_categoria BEFORE INSERT ON aviso_producto FOR EACH ROW
BEGIN
  IF (SELECT c.nombre FROM aviso a JOIN categoria c ON c.id_categoria = a.id_categoria
      WHERE a.id_aviso = NEW.id_aviso) <> 'Producto' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El aviso no pertenece a la categoría Producto';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria` (
  `id_categoria` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) NOT NULL,
  PRIMARY KEY (`id_categoria`),
  UNIQUE KEY `uq_categoria_nombre` (`nombre`),
  CONSTRAINT `ck_categoria_nombre` CHECK (`nombre` in ('Laboral','Producto','Inmobiliario'))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (3,'Inmobiliario'),(1,'Laboral'),(2,'Producto');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permiso`
--

DROP TABLE IF EXISTS `permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permiso` (
  `id_permiso` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) NOT NULL,
  `descripcion` varchar(150) NOT NULL,
  PRIMARY KEY (`id_permiso`),
  UNIQUE KEY `uq_permiso_codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permiso`
--

LOCK TABLES `permiso` WRITE;
/*!40000 ALTER TABLE `permiso` DISABLE KEYS */;
INSERT INTO `permiso` VALUES (1,'listing.view','Ver avisos'),(2,'listing.create','Publicar avisos'),(3,'listing.highlight','Marcar avisos como resaltados'),(4,'listing.delete_own','Eliminar avisos propios'),(5,'listing.delete_any','Eliminar cualquier aviso'),(6,'author.manage','Alta, baja y modificación de autores'),(7,'role.manage','Gestionar roles y permisos'),(8,'backup.run','Ejecutar respaldos'),(9,'backup.audit','Consultar auditoría de respaldos');
/*!40000 ALTER TABLE `permiso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rol`
--

DROP TABLE IF EXISTS `rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rol` (
  `id_rol` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `descripcion` varchar(150) NOT NULL,
  PRIMARY KEY (`id_rol`),
  UNIQUE KEY `uq_rol_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol`
--

LOCK TABLES `rol` WRITE;
/*!40000 ALTER TABLE `rol` DISABLE KEYS */;
INSERT INTO `rol` VALUES (1,'administrador','Control total del sistema'),(2,'publicador','Publica y gestiona sus propios avisos'),(3,'visitante','Solo lectura pública'),(4,'respaldo','Ejecuta y audita copias de seguridad');
/*!40000 ALTER TABLE `rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rol_permiso`
--

DROP TABLE IF EXISTS `rol_permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rol_permiso` (
  `id_rol` tinyint(3) unsigned NOT NULL,
  `id_permiso` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id_rol`,`id_permiso`),
  KEY `fk_rp_permiso` (`id_permiso`),
  CONSTRAINT `fk_rp_permiso` FOREIGN KEY (`id_permiso`) REFERENCES `permiso` (`id_permiso`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rp_rol` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol_permiso`
--

LOCK TABLES `rol_permiso` WRITE;
/*!40000 ALTER TABLE `rol_permiso` DISABLE KEYS */;
INSERT INTO `rol_permiso` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,9),(2,1),(2,2),(2,4),(3,1),(4,8),(4,9);
/*!40000 ALTER TABLE `rol_permiso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_inmueble`
--

DROP TABLE IF EXISTS `tipo_inmueble`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_inmueble` (
  `id_tipo_inmueble` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`id_tipo_inmueble`),
  UNIQUE KEY `uq_tipo_inmueble_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_inmueble`
--

LOCK TABLES `tipo_inmueble` WRITE;
/*!40000 ALTER TABLE `tipo_inmueble` DISABLE KEYS */;
INSERT INTO `tipo_inmueble` VALUES (2,'Apartamento'),(1,'Casa'),(4,'Local comercial'),(3,'Terreno');
/*!40000 ALTER TABLE `tipo_inmueble` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `v_avisos_publicos`
--

DROP TABLE IF EXISTS `v_avisos_publicos`;
/*!50001 DROP VIEW IF EXISTS `v_avisos_publicos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_avisos_publicos` AS SELECT
 1 AS `id_aviso`,
  1 AS `titulo`,
  1 AS `fecha_creacion`,
  1 AS `resaltado`,
  1 AS `autor`,
  1 AS `categoria`,
  1 AS `id_autor`,
  1 AS `referencia`,
  1 AS `detalle`,
  1 AS `monto` */;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'avisos_clasificados'
--

--
-- Dumping routines for database 'avisos_clasificados'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_autor_tiene_permiso` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_autor_tiene_permiso`(p_id_autor INT UNSIGNED, p_codigo VARCHAR(50)) RETURNS tinyint(1)
    READS SQL DATA
    DETERMINISTIC
BEGIN
  RETURN EXISTS (
    SELECT 1
    FROM autor a
    JOIN rol_permiso rp ON rp.id_rol = a.id_rol
    JOIN permiso p      ON p.id_permiso = rp.id_permiso
    WHERE a.id_autor = p_id_autor AND a.activo = 1 AND p.codigo = p_codigo
  );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_backup_finalizar` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_backup_finalizar`(
  IN p_id_backup BIGINT UNSIGNED, IN p_estado VARCHAR(10), IN p_archivo VARCHAR(255),
  IN p_tamano BIGINT UNSIGNED, IN p_checksum CHAR(64), IN p_obs VARCHAR(255))
BEGIN
  UPDATE auditoria_backup
     SET estado = p_estado, fecha_fin = NOW(), archivo = p_archivo,
         tamano_bytes = p_tamano, checksum_sha256 = p_checksum, observaciones = p_obs
   WHERE id_backup = p_id_backup AND estado = 'EN_CURSO';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_backup_iniciar` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_backup_iniciar`(IN p_tipo VARCHAR(30), OUT p_id_backup BIGINT UNSIGNED)
BEGIN
  INSERT INTO auditoria_backup (tipo, estado, fecha_inicio, usuario_bd)
  VALUES (p_tipo, 'EN_CURSO', NOW(), CURRENT_USER());
  SET p_id_backup = LAST_INSERT_ID();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_datos_login` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_datos_login`(IN p_email VARCHAR(120))
BEGIN
  SELECT a.id_autor, a.nombre, a.password_hash, r.nombre AS rol
  FROM autor a JOIN rol r ON r.id_rol = a.id_rol
  WHERE a.email = p_email AND a.activo = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_eliminar_aviso` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_eliminar_aviso`(IN p_id_aviso INT UNSIGNED, IN p_id_autor INT UNSIGNED)
BEGIN
  DECLARE v_dueno INT UNSIGNED;
  SELECT id_autor INTO v_dueno FROM aviso WHERE id_aviso = p_id_aviso;
  IF v_dueno IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El aviso no existe';
  END IF;
  IF fn_autor_tiene_permiso(p_id_autor, 'listing.delete_any')
     OR (v_dueno = p_id_autor AND fn_autor_tiene_permiso(p_id_autor, 'listing.delete_own')) THEN
    DELETE FROM aviso WHERE id_aviso = p_id_aviso;
  ELSE
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sin permiso para eliminar este aviso';
  END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_permisos_autor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_permisos_autor`(IN p_id_autor INT UNSIGNED)
BEGIN
  SELECT p.codigo
  FROM autor a
  JOIN rol_permiso rp ON rp.id_rol = a.id_rol
  JOIN permiso p      ON p.id_permiso = rp.id_permiso
  WHERE a.id_autor = p_id_autor AND a.activo = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_publicar_inmobiliario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_publicar_inmobiliario`(
  IN p_id_autor INT UNSIGNED, IN p_titulo VARCHAR(150), IN p_resaltado TINYINT(1),
  IN p_id_tipo TINYINT UNSIGNED, IN p_ubicacion VARCHAR(150),
  IN p_superficie DECIMAL(10,2), IN p_precio DECIMAL(14,2),
  OUT p_id_aviso INT UNSIGNED)
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;
  IF NOT fn_autor_tiene_permiso(p_id_autor, 'listing.create') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sin permiso: listing.create';
  END IF;
  IF p_resaltado = 1 AND NOT fn_autor_tiene_permiso(p_id_autor, 'listing.highlight') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sin permiso: listing.highlight';
  END IF;
  START TRANSACTION;
    INSERT INTO aviso (titulo, resaltado, id_autor, id_categoria)
      SELECT p_titulo, p_resaltado, p_id_autor, id_categoria FROM categoria WHERE nombre = 'Inmobiliario';
    SET p_id_aviso = LAST_INSERT_ID();
    INSERT INTO aviso_inmobiliario (id_aviso, id_tipo_inmueble, ubicacion, superficie_m2, precio)
      VALUES (p_id_aviso, p_id_tipo, p_ubicacion, p_superficie, p_precio);
  COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_publicar_laboral` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_publicar_laboral`(
  IN p_id_autor INT UNSIGNED, IN p_titulo VARCHAR(150), IN p_resaltado TINYINT(1),
  IN p_empresa VARCHAR(100), IN p_cargo TEXT, IN p_sueldo DECIMAL(10,2),
  OUT p_id_aviso INT UNSIGNED)
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;
  IF NOT fn_autor_tiene_permiso(p_id_autor, 'listing.create') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sin permiso: listing.create';
  END IF;
  IF p_resaltado = 1 AND NOT fn_autor_tiene_permiso(p_id_autor, 'listing.highlight') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sin permiso: listing.highlight';
  END IF;
  START TRANSACTION;
    INSERT INTO aviso (titulo, resaltado, id_autor, id_categoria)
      SELECT p_titulo, p_resaltado, p_id_autor, id_categoria FROM categoria WHERE nombre = 'Laboral';
    SET p_id_aviso = LAST_INSERT_ID();
    INSERT INTO aviso_laboral (id_aviso, empresa, descripcion_cargo, sueldo_mensual)
      VALUES (p_id_aviso, p_empresa, p_cargo, p_sueldo);
  COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_publicar_producto` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_publicar_producto`(
  IN p_id_autor INT UNSIGNED, IN p_titulo VARCHAR(150), IN p_resaltado TINYINT(1),
  IN p_descripcion TEXT, IN p_precio DECIMAL(12,2),
  OUT p_id_aviso INT UNSIGNED)
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;
  IF NOT fn_autor_tiene_permiso(p_id_autor, 'listing.create') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sin permiso: listing.create';
  END IF;
  IF p_resaltado = 1 AND NOT fn_autor_tiene_permiso(p_id_autor, 'listing.highlight') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sin permiso: listing.highlight';
  END IF;
  START TRANSACTION;
    INSERT INTO aviso (titulo, resaltado, id_autor, id_categoria)
      SELECT p_titulo, p_resaltado, p_id_autor, id_categoria FROM categoria WHERE nombre = 'Producto';
    SET p_id_aviso = LAST_INSERT_ID();
    INSERT INTO aviso_producto (id_aviso, descripcion_producto, precio)
      VALUES (p_id_aviso, p_descripcion, p_precio);
  COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `v_avisos_publicos`
--

/*!50001 DROP VIEW IF EXISTS `v_avisos_publicos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_avisos_publicos` AS select `a`.`id_aviso` AS `id_aviso`,`a`.`titulo` AS `titulo`,`a`.`fecha_creacion` AS `fecha_creacion`,`a`.`resaltado` AS `resaltado`,`au`.`nombre` AS `autor`,`c`.`nombre` AS `categoria`,`a`.`id_autor` AS `id_autor`,coalesce(`l`.`empresa`,`ti`.`nombre`) AS `referencia`,coalesce(`l`.`descripcion_cargo`,`p`.`descripcion_producto`,`i`.`ubicacion`) AS `detalle`,coalesce(`l`.`sueldo_mensual`,`p`.`precio`,`i`.`precio`) AS `monto` from ((((((`aviso` `a` join `autor` `au` on(`au`.`id_autor` = `a`.`id_autor`)) join `categoria` `c` on(`c`.`id_categoria` = `a`.`id_categoria`)) left join `aviso_laboral` `l` on(`l`.`id_aviso` = `a`.`id_aviso`)) left join `aviso_producto` `p` on(`p`.`id_aviso` = `a`.`id_aviso`)) left join `aviso_inmobiliario` `i` on(`i`.`id_aviso` = `a`.`id_aviso`)) left join `tipo_inmueble` `ti` on(`ti`.`id_tipo_inmueble` = `i`.`id_tipo_inmueble`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-25 17:05:10
